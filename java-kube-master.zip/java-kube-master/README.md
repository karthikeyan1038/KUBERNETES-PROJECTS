<<<<<<< HEAD
Hello World! (WAR-style)
===============

This is the simplest possible Java webapp for testing servlet container deployments.  It should work on any container and requires no other dependencies or configuration.
=======
<<<<<<< HEAD
# java

java application
=======
# java-kube

>>>>>>> d52fad6b9691e191bb9a1eb5224368bea2e99dba
>>>>>>> 8a9c99c50b4bd655e8d60c4746dbf3d3a5447119
