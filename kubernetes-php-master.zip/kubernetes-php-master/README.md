
# kubernetes-php
The PHP application image is hosted on [zippyops01's Docker Hub]()
=======https://hub.docker.com/r/zippyops01/php

# Heptio's LAMP on K8s Example Stack and Application

This is the companion Kubernetes LAMP stack and PHP application for [Tutorial: How to Run a Custom LAMP Application on Kubernetes](http://docs.heptio.com/content/tutorials/lamp.html)


